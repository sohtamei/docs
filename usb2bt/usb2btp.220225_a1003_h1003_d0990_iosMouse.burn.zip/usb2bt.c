#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <time.h>


#define GotoError(fmt, args...) { fprintf(stderr, "Err in %s(%d):" fmt "\n", __FUNCTION__, __LINE__, ##args); goto Error; }

static char*  uartDev = NULL;

static int SerialPort1Open(void)
{
	struct termios  ios;
	int ret;
	int fd;
	fd = open(uartDev, O_RDWR | O_NOCTTY | O_NONBLOCK);
	if(fd < 0) GotoError("cannot open %s", uartDev);

	memset(&ios, 0, sizeof(ios));
	ios.c_iflag = 0;
	ios.c_oflag = 0;
	ios.c_cflag = CS8 | CLOCAL | CREAD | B115200;
	ios.c_cc[VTIME] = 0;
	ios.c_cc[VMIN] = 1;
	tcflush(fd, TCIFLUSH);
	tcsetattr(fd, TCSANOW, &ios);

	return fd;
Error:
	return -1;
}

static void SerialPort1Close(int fd)
{
	tcdrain(fd);
	close(fd);
}

static void SerialPort1ReadExisting(int fd)
{
	tcflush(fd, TCIFLUSH);
}

static int SerialPort1Read(int fd, void* buf, int size, int waitSec)
{
	int  ret = 0;
	fd_set  fds;
	struct timeval  time;

	FD_ZERO(&fds);
	FD_SET(fd, &fds);
	time.tv_sec = waitSec;
	time.tv_usec = 0;

	while(1) {
		ret = select(fd + 1, &fds, NULL, NULL, &time);
		if(ret < 0) GotoError("");
		if(ret == 0) return 0;

		if(FD_ISSET(fd, &fds)) {
			ret = read(fd, buf, size);
			((char*)buf)[ret] = '\0';
			return ret;
		}
	}
Error:
	return -1;
}

static int SerialPort1ReadLineTimeout(int fd, char* buf, int size, int waitSec)
{
	int  ret = 0;
	fd_set  fds;
	struct timeval  time;

	FD_ZERO(&fds);
	FD_SET(fd, &fds);
	time.tv_sec = waitSec;
	time.tv_usec = 0;

	int i = 0;
	int size2 = 0;
	while(1) {
		ret = select(fd + 1, &fds, NULL, NULL, &time);
		if(ret < 0) GotoError("");
		if(ret == 0) goto Error;
		size2 += ret;

		if(FD_ISSET(fd, &fds)) {
			while(i < size2) {
				unsigned char byte;
				ret = read(fd, &byte, 1);
				if(ret > 0) {
					switch(byte) {
					default:
						buf[i] = byte;
						i++;
						break;
					case '\r':
						break;
					case '\n':
						goto exit_;
					}
					if(i >= size) goto exit_;
				}
				}
		}
	}
exit_:
	buf[i] = '\0';
//	printf("%s\n", buf);	// for debug
	return i;
Error:
	return -1;
}

static int SerialPort1WaitLine(int fd, char* mes, char* buf, int size, int waitSec)
{
	int ret;
	int len = strlen(mes);
	char txtLine[256];
	while(1) {
		ret = SerialPort1ReadLineTimeout(fd, txtLine, sizeof(txtLine), waitSec);
		if(ret < 0) return 1;
		if(!strncmp(txtLine, mes, len)) {
			strncpy(buf, txtLine+len, size);
			return 0;
		}
	}
}

static void dumpBuf(char* mes, uint8_t* buf, int size)
{
#if 0
	int i;
	printf("%s", mes);
	for(i = 0; i < size; i++)
		printf("%02x", buf[i]);
	printf("\n");
#endif
}

//-------------------------------------------------------------------------
// USB2BTplus - 2018/04/17

#define TIMEOUT_BURN	5

enum {
	dev_pic2dev = 0,
	dev_pic1host,
	dev_wlan,
	dev_all,
};

static char currentVer[3][16];
static char latestVer[3][16];

static int buttonReadVer(void)
{
	memset(currentVer, 0, sizeof(currentVer));
	memset(latestVer, 0, sizeof(latestVer));
	char txtLine[256];
	FILE* fp = NULL;
	int ret;
	int result = 1;
	int fd = -1;

	fp = fopen("latest.ver.txt", "r");
	if(!fp) GotoError("");
	fgets(txtLine, sizeof(txtLine), fp);
	fclose(fp);

	int i;
	char* dp1 = txtLine;
	char* dp2;
	for(i = 0; i < 3; i++) {
		dp2 = strchr(dp1, (i==2) ? '\n':' ');
		if(!dp2) break;
		strncpy(latestVer[i], dp1, dp2-dp1);
		latestVer[i][dp2-dp1] = '\0';
		dp1 = dp2+1;
	}

	fd = SerialPort1Open();
	if(fd<0) GotoError("");

	// I - 
	SerialPort1ReadExisting(fd);
	write(fd, "I\n", sizeof("I\n")-1);
	SerialPort1ReadLineTimeout(fd, txtLine, sizeof(txtLine), 1);
	clock_t startTime = clock();
	while(1) {
		ret = SerialPort1ReadLineTimeout(fd, txtLine, sizeof(txtLine), 1);
		if(ret < 0) GotoError("");
		if(!strncmp(txtLine, "hostVer=", sizeof("hostVer=")-1)) {
			strncpy(currentVer[dev_pic1host], txtLine+sizeof("hostVer=")-1, sizeof(currentVer[0]));
			printf("PIC1:%s->%s\n", currentVer[dev_pic1host], latestVer[dev_pic1host]);
			break;
		} else if(!strncmp(txtLine, "HostVer=", sizeof("HostVer=")-1)) {
			printf("PIC1:Boot\n");
			goto Reset;
		} else if(!strncmp(txtLine, "DevVer=", sizeof("DevVer=")-1)) {
			printf("PIC2:Boot\n");
			goto Reset;
		} else if(!strncmp(txtLine, "wlanVer=", sizeof("wlanVer=")-1)) {
			printf("WLAN:Boot\n");
			goto Reset;
		}
		if(clock() - startTime >= TIMEOUT_BURN*CLOCKS_PER_SEC) GotoError("");
	}

	usleep(500*1000);
	SerialPort1ReadExisting(fd);
	write(fd, "I0\n", sizeof("I0\n")-1);
	SerialPort1WaitLine(fd, "devVer=", currentVer[dev_pic2dev], sizeof(currentVer[0]), 1);
	printf("PIC2:%s->%s\n", currentVer[dev_pic2dev], latestVer[dev_pic2dev]);

	usleep(100*1000);
	write(fd, "I2\n", sizeof("I2\n")-1);
	SerialPort1WaitLine(fd, "wlanVer=", currentVer[dev_wlan], sizeof(currentVer[0]), 5);
	printf("WLAN:%s->%s\n", currentVer[dev_wlan], latestVer[dev_wlan]);

	result = 0;
Error:
	SerialPort1Close(fd);
	return result;
Reset:
	write(fd, "R\n", sizeof("R\n")-1);
	SerialPort1Close(fd);
	sleep(4);
	return 0;
}

// PICアップデート ----------------------------------------------------------------------------

#define FlashPage		0x1D000000
#define FlashSize		0x20000
#define AppSigOffset	0x5C90	// PIC1
#define AppVerOffset	0x5C94	// 0900

static int loadPicFW(char* filename, uint8_t* binBuf, uint32_t* binSize)
{
	int bufSize = *binSize;
	FILE* fs = NULL;
	fs = fopen(filename, "r");
	if(!fs) GotoError("");
	int ret;

	memset(binBuf, 0xFF, bufSize);
	int i;
	uint32_t baseAdrs;
	while(1) {
		char lineText[256];
		char* dp;
		uint8_t lineBuf[4 + 32 + 1];
		dp = fgets(lineText, sizeof(lineText), fs);
		if(!dp) break;
		dp = strchr(lineText, '\r'); if(dp) *dp = '\0';
		dp = strchr(lineText, '\n'); if(dp) *dp = '\0';

		//:02 0000 04 1D00 DD
		//:10 0000 00 E54F1D2314D0B3410080450E440CA60E CD
		if(lineText[0] != ':') GotoError("File error")
		int size = strlen(lineText) - 1;

		uint32_t sum = 0;
		char tmp[3] = {0};
		for(i = 0; i < size / 2; i++) {
			tmp[0] = lineText[1+i*2+0];
			tmp[1] = lineText[1+i*2+1];
			lineBuf[i] = strtoul(tmp, NULL, 16);
			sum += lineBuf[i];
		}

		if(lineBuf[0] != size / 2 - 5) GotoError("File error");
		if((sum % 0x100) != 0) GotoError("File error")

		switch(lineBuf[3]) {
		case 0:
			if((baseAdrs & 0xFF000000) == FlashPage) {
				uint32_t offset;
				offset = (baseAdrs & 0xFFFFFF) + lineBuf[1] * 0x100UL + lineBuf[2];
				if(*binSize < offset + lineBuf[0]) *binSize = offset + lineBuf[0];
				if(*binSize > bufSize) GotoError("File error");

				memcpy(binBuf+offset, lineBuf+4, lineBuf[0]);
			}
			break;
		case 4:
			baseAdrs = lineBuf[4] * 0x1000000UL + lineBuf[5] * 0x10000UL;
			break;
		}
	}
	fclose(fs);

	*binSize = (*binSize + 1023) & ~1023;
	if((*binSize <= 0x5000)) GotoError("File error")
	return 0;
Error:
	return 1;
}

static int burnPIC(int devIndex, char* picFileName)
{
	int ret;

	int fd = -1;
	fd = SerialPort1Open();
	if(fd<0) GotoError("");

	int i;
	uint8_t binBuf[FlashSize];
	uint32_t binSize = sizeof(binBuf);;
	ret = loadPicFW(picFileName, binBuf, &binSize);
	if(ret) goto Error;

	char tmp[16];
	snprintf(tmp, sizeof(tmp), "\nU%d\n", devIndex);
	write(fd, tmp, strlen(tmp));
	SerialPort1Close(fd);

	if(devIndex == dev_pic2dev) {
		#define WaitRebooting	10	// PIC起動待ち [sec]
		for(i = 0; i < WaitRebooting; i++) {
			sleep(1);
			printf("%d\n", i);
		}
	}

	fd = SerialPort1Open();
	if(fd<0) GotoError("");
	uint8_t rcvBuf[65536];
	uint8_t sendBuf[5 + 1024];
	uint32_t readNum;

	// R:"C"
	clock_t startTime = clock();
	while(1) {
		readNum = SerialPort1Read(fd, rcvBuf, sizeof(rcvBuf), 5);
		if((readNum > 0) && (rcvBuf[0] == 'C')) break;
		if(clock() - startTime >= TIMEOUT_BURN*CLOCKS_PER_SEC) GotoError("");
	}
	dumpBuf("R:", rcvBuf, readNum);

	//W:01 00 FF (SOH,Block0)
	//	"abc.txt" 00
	//	"519 12715566427 100644"
	sendBuf[0] = 0x1;
	sendBuf[1] = 0x0;
	sendBuf[2] = 0xFF;
	sendBuf[3] = 'X';	// filename(dummy)
	sendBuf[4] = 0;
	snprintf((char*)sendBuf+5, sizeof(sendBuf)-5, "%d", binSize);
	write(fd, sendBuf, 5 + 128);
	dumpBuf("W:", sendBuf, 5 + 128);

	//R:06(ACK)
	//R:"C"
	startTime = clock();
	while(1) {
		readNum = SerialPort1Read(fd, rcvBuf, 1, 5);
		dumpBuf("R:", rcvBuf, readNum);
		if(readNum <= 0) GotoError("");
		if(rcvBuf[0] == 0x6) break;
		if(clock() - startTime >= TIMEOUT_BURN*CLOCKS_PER_SEC) GotoError("");
	}

	readNum = SerialPort1Read(fd, rcvBuf, sizeof(rcvBuf), 5);
	dumpBuf("R:", rcvBuf, readNum);
	if((readNum == 0) || (rcvBuf[0] != 'C')) GotoError("");

	for(i = 0; i < (binSize / 1024); i++) { 
		//W:02 01 FE (STX,Block1)
		sendBuf[0] = 0x2;
		sendBuf[1] = i + 1;
		sendBuf[2] = 255 - (i + 1);
		memcpy(sendBuf+3, binBuf + i*1024, 1024);
		int j;
		for(j = 0; j < 5 + 1024; j+=128) {
			int size = 5+1024 - j;
			if(size > 128) size = 128;
			write(fd, sendBuf+j, size);
			tcdrain(fd);
		}
		dumpBuf("W:", sendBuf, 5 + 1024);

		//R:06(ACK)
		readNum = SerialPort1Read(fd, rcvBuf, sizeof(rcvBuf), 10);
		dumpBuf("R:", rcvBuf, readNum);
		if((readNum == 0) || (rcvBuf[0] != 0x6)) GotoError("");
		if(!(i&15)) printf("%d\n", i>>4);
	}

	//W:04(EOT)
	//R:15(NAK)
	//W:04(EOT)
	//R:06(ACK)
	sendBuf[0] = 0x4;
	write(fd, sendBuf, 1);
	dumpBuf("W:", sendBuf, 1);
	readNum = SerialPort1Read(fd, rcvBuf, sizeof(rcvBuf), 5);
	dumpBuf("R:", rcvBuf, readNum);

	sendBuf[0] = 0x4;
	write(fd, sendBuf, 1);
	dumpBuf("W:", sendBuf, 1);
	readNum = SerialPort1Read(fd, rcvBuf, sizeof(rcvBuf), 5);
	dumpBuf("R:", rcvBuf, readNum);
	if((readNum == 0) || (rcvBuf[0] != 0x6)) GotoError("");

	//R:"C"
	//W:01 00 FF (SOH,Block0)
	//	00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 
	//	00 00
	//R:06(ACK)

	//W:"R"
	write(fd, "\nR\n", sizeof("\nR\n")-1);
	SerialPort1Close(fd);
	sleep(4);
	return 0;
Error:
	SerialPort1Close(fd);
	return 1;
}


int main(int argc, char* argv[])
{
	int ret = 1;

	if(argc < 2) GotoError("usage:cmd /dev/tty.usbmodemXXXX [u|u1|u2] [filename]");

	uartDev = argv[1];

	ret = buttonReadVer();

	if(argc < 3) {
		;
	} else if(!strcmp(argv[2], "u")) {
		if(strtod(latestVer[dev_pic2dev], NULL) > strtod(currentVer[dev_pic2dev], NULL)) {
			printf("update PIC2\n");
			ret = burnPIC(dev_pic2dev, "latest.pic2.hex");
			if(ret) goto Error;
		}

		if(strtod(latestVer[dev_pic1host], NULL) > strtod(currentVer[dev_pic1host], NULL)) {
			printf("update PIC1\n");
			ret = burnPIC(dev_pic1host, "latest.pic1.hex");
			if(ret) goto Error;
		}
/*
		if(strtod(latestVer[dev_wlan], NULL) > strtod(currentVer[dev_wlan], NULL)) {
			ret = burnWlan();
		}
*/
	} else if(!strcmp(argv[2], "u2")) {
		ret = burnPIC(dev_pic2dev, (argc >= 4) ? argv[3]: "latest.pic2.hex");
		if(ret) goto Error;

		int fd = SerialPort1Open();
		if(fd<0) GotoError("");
		write(fd, "\nR1\n", sizeof("\nR1\n")-1);
		SerialPort1Close(fd);

	} else if(!strcmp(argv[2], "u1")) {
		ret = burnPIC(dev_pic1host, (argc >= 4) ? argv[3]: "latest.pic1.hex");
	}
	if(!ret) printf("SUCCEEDED!.\n");
Error:
	return ret;
}
